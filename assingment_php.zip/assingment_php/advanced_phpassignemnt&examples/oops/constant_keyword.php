<?php
class A
{

    //constant variable create here

    const a="This is a Brijesh";

}

echo A::a;  // :: scope resulation operator


?>