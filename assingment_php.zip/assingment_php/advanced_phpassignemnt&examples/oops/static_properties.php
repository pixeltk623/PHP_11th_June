<?php
class name
{
   public static $value="My name is Brijesh";

}


echo name::$value;


?>