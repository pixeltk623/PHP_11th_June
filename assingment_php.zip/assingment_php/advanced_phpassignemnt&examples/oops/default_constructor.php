<?php
class abc
{
    public function __construct()

    {
    
        $name="My name is Brijesh";
        echo $name;

    }
}

$obj=new abc();

?>