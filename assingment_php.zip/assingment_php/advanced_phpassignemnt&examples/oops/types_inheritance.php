<?php


//single inheritance

//multilevel inheritance

//multiple inheritance (not supported in java and php)



?>