<?php
class ABC
{
  public function test()
  
  {
   
    $name="<h3 align='center'>Hi i am Brijesh</h3>";


    echo $name;


  }


}

$obj=new ABC();  //object of class
$obj->test();

?>