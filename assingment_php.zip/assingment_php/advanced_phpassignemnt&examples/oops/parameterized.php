<?php
class abc
{
    
    public function __construct($a,$b)

      {
              

        $c=$a+$b;
        echo "Additions are :".$c;

        

      }

}

$obj=new abc(45,60);

?>