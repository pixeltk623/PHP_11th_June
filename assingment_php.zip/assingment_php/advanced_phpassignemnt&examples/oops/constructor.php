<?php
class A
{
    public function A()

    {
     
        $name="Hello i am User defined Constructor";

        echo $name;

    }
  
}

$obj=new A();


?>