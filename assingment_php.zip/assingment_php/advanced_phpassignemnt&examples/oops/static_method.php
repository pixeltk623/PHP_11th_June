<?php
class a

{
    public static function display()

    {


        echo "My name is Brijesh";
    }


}

//call static method 

a::display();




?>