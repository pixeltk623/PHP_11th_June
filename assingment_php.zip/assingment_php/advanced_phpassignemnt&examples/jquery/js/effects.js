$(document).ready(function(){

  
    $("#btn").click(function(){

     
        $("#para").hide(3000);



    });

    $("#btn1").click(function(){

     
        $("#para").show(3000);



    });



    $("#btn2").click(function(){

     
        $("#para").toggle(3000);



    });


})