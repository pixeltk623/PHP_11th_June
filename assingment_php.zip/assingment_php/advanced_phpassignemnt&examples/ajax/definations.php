#ajax :asynchrounous javascript and xml

#asynchrounous : synchronised data from server

#javascript : for used events and all

#xml : xtensible markup language load dynamic data from server

# ajax used to load data from server withoud refresh of page or reload of page there we can used ajax

ex: google ,youtube etc

#fast load data from server

ajax ready function or ready state :

  0 state :not initialised any data to load

  1 state : initialised data from server

  2 state : initiatialed and statrt to load data from server

  3 state :send request to client and server communications 

  4 state :  load succfully data withou page refresh 

  


