
<div class="bnr" id="home">
		<div  id="top" class="callbacks_container">
			<ul class="rslides" id="slider4">
			    <li>
					<img src="<?php echo $baseurl;?>images/bnr1.jpg" alt="1"/>
				</li>
				<li>
					<img src="<?php echo $baseurl;?>images/bnr2.jpg" alt="2"/>
				</li>
				<li>
					<img src="<?php echo $baseurl;?>images/bnr3.jpg" alt="3"/>
				</li>
			</ul>
		</div>
		<div class="clearfix"> </div>
	</div>
	