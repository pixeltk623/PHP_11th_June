<?php
$mainurl="http://luxurywatch.byethost9.com/admin/";
$baseurl="http://luxurywatch.byethost9.com/admin/assets/";


?>
<div class="container-fluid">
<div class="row">
	
<center>
			
            <img src="<?php echo $baseurl;?>images/404.png">
            
			</center>
            	</div>
		</div>
	</div>
	<!--product-end-->
	<!--information-starts-->
