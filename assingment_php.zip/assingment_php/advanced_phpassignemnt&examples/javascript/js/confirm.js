function del()
{
  
    if(confirm('Are You sure to Delete ?'))
    {

        alert('Your Data deleted Successfully')
        window.location='http://onlineportfolio.byethost14.com';
    }

    else
    {

        alert('sry cant deleted some problems faced try again')
        window.location='delete.html';
    }
   

}