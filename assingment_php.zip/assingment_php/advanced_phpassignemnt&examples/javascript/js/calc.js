function calculate()

{
  
    var a=parseInt(prompt('Enter a values :'));
    
    var b=parseInt(prompt('Enter b values :'));

    var c=a+b;

    alert('Addtions of two numbers are :'+c)




}


function calculate1()

{
  
    var a=parseInt(prompt('Enter a values :'));
    
    var b=parseInt(prompt('Enter b values :'));

    var c=a*b;

    alert('Multiplications of two numbers are :'+c)




}


function calculate2()

{
  
    var a=parseInt(prompt('Enter a values :'));
    
    var b=parseInt(prompt('Enter b values :'));

    var c=a/b;

    alert('Divisions of two numbers are :'+c)




}


