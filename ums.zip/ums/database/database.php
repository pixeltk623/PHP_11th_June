<?php 
	
	$conn = mysqli_connect("localhost","root","","php_11th_june");
	if (!$conn) {
		echo "DB Error";
	}
?>